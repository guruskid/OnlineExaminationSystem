<?php

			$rs3=mysql_query("select * from Automobile where Reg_No='$Reg_No'",$cn2) or die(mysql_error());
			if(mysql_num_rows($rs3)<1)
					{
						echo "<BR><BR><BR><BR><div class=head1> Invalid Roll No<div>";
						exit;
						
					}
					$_SESSION[login]="true";

?>