<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
	<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

			<link rel='stylesheet' id='google_font_Open_Sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C400italic%2C600%2C600italic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin%2Cvietnamese%2Cgreek%2Ccyrillic-ext%2Clatin-ext%2Ccyrillic%2Cgreek-ext' type='text/css' media='all' />

			<link href="scripts/bxslider/jquery.bxslider.css" rel="stylesheet" />
			<link href="scripts/rs-plugin/css/settings.css" rel="stylesheet" type="text/css" media="screen" />
			<link href="scripts/magnific-popup/magnific-popup.css" rel="stylesheet" />
			<link href="scripts/magnific-popup/magnific-popup-anim.css" rel="stylesheet" />
			<link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="scripts/entypo/entypo.css">
			<link rel="stylesheet" href="scripts/zocial/zocial.css">
			<link rel="stylesheet" href="style.css" type="text/css"/>
			<link id="skin-style-css" rel="stylesheet" href="skins/blue/blue.css" type="text/css"/>
			<link href="scripts/colorpicker/css/colorpicker.css" rel="stylesheet" />
			<link rel="stylesheet" href="switcher/switcher.css" type="text/css"/>
			
			<link rel="stylesheet" href="css/bootstrap.min.css">
    		<script src="js/respond.js"></script>

    		<style type='text/css'>
				body.boxed{ 
					background-color: #F5D29D; 
					background-image: url("images/boxed_wood.jpg");background-repeat: repeat;}

					@media only screen and (min-width:600px) and (max-width:1000px){
					body{
					width:100%;
					}
					}
			
			</style>			
					
			<title>
				Online Exam
			</title>
	</head>

	<body>	
	<footer class="row">	
	<div class="footer_push"></div>
	</div><!-- END content_container-->
	<div class="footer_container">
		<div class="footer-social_container cwidth_container">
	<div class="footer-social_wrapper cwidth_wrapper">
		<div class="footer-social cwidth">
			<div class="col-1-1">
				<div class="col">
					<ul class="timeline">
						
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>		<div class="footer-widgets_container cwidth_container">
	<div class="footer-widgets_wrapper cwidth_wrapper">
		<div class="footer-widgets cwidth">



	<div class="footer-bottom_container cwidth_container">
	<div class="footer-bottom_wrapper cwidth_wrapper">
		<div class="footer-bottom cwidth">
			<div class="col-1-1">
				<div class="col">
					<div class="footer-bottom_content clearfix">
						<a class="logo_footer" href="index.html">
							
						</a>
						<div class="footer-bottom_left">
							© Copyright 2014 by Government Polytechnic Nashik. All Rights Reserved.
						</div>
						<div class="footer-bottom_right">
							<div class="footer_links">
							
								<a href="contact.html">Contact</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>	</div>
</footer>

		<!--javascript-->

		<script src="http://code.jquery.com/jquery-latest.min.js"></script>
		<script src="js/bootstrap.min.js"></script>

</body>
</div>

</html>