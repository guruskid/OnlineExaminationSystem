/*
	jQuery document ready
*/
$(function()
{
	/***
		set timer countdown in seconds with callback
		where 10 define the second left in count.
		after 10 second it will show alert.
		wait for 10 second to see it.
	*/
	
	$('#countdown-1').timeTo(3600, function()
	{
		alert('Countdown finished');
	});

	
});