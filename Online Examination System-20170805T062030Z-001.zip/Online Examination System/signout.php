<?php
session_start();
session_destroy();
header("Location: FHP4.php");
?>
