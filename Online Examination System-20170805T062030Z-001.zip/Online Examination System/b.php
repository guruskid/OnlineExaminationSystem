<?php
include("a.php");
echo "<a href=fhp4.php>Start</a>";
?>