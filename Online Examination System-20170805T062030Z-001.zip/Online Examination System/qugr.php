if($q=1){ $s1="green";}if($q=2){ $s2="green";} if($q=3){ $s3="green";} if($q=4){ $s4="green";} if($q=5){ $s5="green";} if($q=6){ $s6="green";} if($q=7){ $s7="green";}
						 if($q=8){ $s8="green";} if($q=9){ $s9="green";} if($q=10){ $s10="green";} if($q=11){ $s11="green";} if($q=12){ $s12="green";} if($q=13){ $s13="green";} if($q=14){ $s14="green";}
						 if($q=15){ $s15="green";} if($q=16){ $s16="green";} if($q=17){ $s17="green";}if($q=18){ $s18="green";} if($q=19){ $s19="green";}if($q=20){ $s20="green";}if($q=21){ $s21="green";}
						 if($q=22){ $s22="green";} if($q=23){ $s23="green";} if($q=24){ $s24="green";}if($q=25){ $s25="green";} if($q=26){ $s26="green";}if($q=27){ $s27="green";}if($q=28){ $s29="green";}
						 if($q=30){ $s30="green";} if($q=31){ $s31="green";} if($q=32){ $s32="green";}if($q=33){ $s33="green";} if($q=34){ $s34="green";}if($q=35){ $s35="green";}if($q=36){ $s36="green";}
						 if($q=37){ $s37="green";} if($q=38){ $s38="green";} if($q=39){ $s39="green";} if($q=40){ $s40="green";} if($q=41){ $s41="green";}
					

					//MAth 
					if($q=1){ $s1="green";}else if($q=2){ $s2="green";}else if($q=3){ $s3="green";}else if($q=4){ $s4="green";}else if($q=5){ $s5="green";}else if($q=6){ $s6="green";}else if($q=7){ $s7="green";}
						 else if($q=8){ $s8="green";}else if($q=9){ $s9="green";}else if($q=10){ $s10="green";}else if($q=11){ $s11="green";}else if($q=12){ $s12="green";}else if($q=13){ $s13="green";} else if($q=14){ $s14="green";}
						 else if($q=15){ $s15="green";} else if($q=16){ $s16="green";}else if($q=17){ $s17="green";}else if($q=18){ $s18="green";} else if($q=19){ $s19="green";}else if($q=20){ $s20="green";}else if($q=21){ $s21="green";}
						 else if($q=22){ $s22="green";} else if($q=23){ $s23="green";}else if($q=24){ $s24="green";}else if($q=25){ $s25="green";} else if($q=26){ $s26="green";}else if($q=27){ $s27="green";}else if($q=28){ $s28="green";}
						 else if($q=30){ $s30="green";} else if($q=31){ $s31="green";}else if($q=32){ $s32="green";}else if($q=33){ $s33="green";} else if($q=34){ $s34="green";}else if($q=35){ $s35="green";}else if($q=36){ $s36="green";}
						 else if($q=37){ $s37="green";} else if($q=38){ $s38="green";}else if($q=39){ $s39="green";}else if($q=40){ $s40="green";}else if($q=29){ $s29="green";}
					