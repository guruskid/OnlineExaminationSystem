<!DOCTYPE html>
<html>
<body>

<?php
echo readfile("EXTRAS_AFTER_LOGIN.txt");
?>

</body>
</html>