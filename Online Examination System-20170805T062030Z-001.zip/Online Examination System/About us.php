<html>
	<head>
		<title>About us</title>

		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Home Page</title>
        <meta name="description" content="Custom Login Form Styling with CSS3" />
        <meta name="keywords" content="css3, login, form, custom, input, submit, button, html5, placeholder" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/style.css" />
    <script src="js/modernizr.custom.63321.js"></script>
    <!--[if lte IE 7]><style>.main{display:none;} .support-note .note-ie{display:block;}</style><![endif]--><meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" type="text/css" href="styles.css" />
<link rel="stylesheet" type="text/css" href="style.css" />
			<link rel='stylesheet' id='google_font_Open_Sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C400italic%2C600%2C600italic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin%2Cvietnamese%2Cgreek%2Ccyrillic-ext%2Clatin-ext%2Ccyrillic%2Cgreek-ext' type='text/css' media='all' />

			<link href="scripts/bxslider/jquery.bxslider.css" rel="stylesheet" />
			<link href="scripts/rs-plugin/css/settings.css" rel="stylesheet" type="text/css" media="screen" />
			<link href="scripts/magnific-popup/magnific-popup.css" rel="stylesheet" />
			<link href="scripts/magnific-popup/magnific-popup-anim.css" rel="stylesheet" />
			<link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="scripts/entypo/entypo.css">
			<link rel="stylesheet" href="scripts/zocial/zocial.css">
			<link rel="stylesheet" href="style.css" type="text/css"/>
			<link id="skin-style-css" rel="stylesheet" href="skins/blue/blue.css" type="text/css"/>
			<link href="scripts/colorpicker/css/colorpicker.css" rel="stylesheet" />
			<link rel="stylesheet" href="switcher/switcher.css" type="text/css"/>
		<link rel="stylesheet" href="css/bootstrap.min.css">
    	<script src="js/respond.js"></script>
	</head>
	<style>
		p{text-indent: 50px;}
	</style>

	<body>
		<div class="container">
			<u><center><h1>About Us</h1></center></u>
		
			<i><p>Government Polytechnic, Nashik is an autonomous institute committed to provide engineering and technology diploma, post diploma and certificate program that cater to the changing need of industry, business and community at large using need based curricula, delivered in dynamic learning environment, to mobilize the required resources by providing continuing education, testing and consultancy to industry, business and community. </p></i>
			<p >This is an online exam application designed for  Governmant Polytechnic Nashik,An Autonomous Institute of Government of Maharashtra.<br></p>
			<p >This application is prepared keeping in mind the advancement and simplicity in the age of Computers and Internet.This software and all its rights solely  belong to this institute only.</p></i>

		

		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
		    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="5"></li>
		  </ol>

		  <!-- Wrapper for slides -->
		  <div class="carousel-inner" role="listbox">
		    <div class="item active">
		      <img src="images/gpn1.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		        ...
		      </div>
		    </div>

		    <div class="item">
		      <img src="images/gpn2.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		       ... 
		      </div>
		    </div>

		    <div class="item">
		      <img src="images/gpn3.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		        ...
		      </div>
		    </div>
		    
			<div class="item">
		      <img src="images/gpn4.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		        ...
		      </div>
		    </div>

		    <div class="item">
		      <img src="images/gpn5.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		        ...
		      </div>
		    </div>
		    
		    <div class="item">
		      <img src="images/gpn6.jpg" height="480"width="640"alt="...">
		      <div class="carousel-caption">
		        ...
		      </div>
		    </div>
		    
		    

		  </div>

		  <!-- Controls -->
		  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>

		<br><br>&nbsp &nbsp &nbsp &nbsp &nbsp<span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>&nbsp Phone :(0253) 2461221

		<br><br>&nbsp &nbsp &nbsp &nbsp &nbsp<span class="glyphicon glyphicon-globe" aria-hidden="true"></span>&nbsp coe@gpnashik.org.in

		<br><br>&nbsp &nbsp &nbsp &nbsp &nbsp<span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>&nbsp <a href="http://gpnashik.org.in/web/">Visit to website</a>

		<br><br>&nbsp &nbsp &nbsp &nbsp &nbsp<span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp Government Polytechnic Nashik ,Samangaon Road ,Nashik Road ,Nashik-422101.
	
		<!--javascript-->

		<script src="http://code.jquery.com/jquery-latest.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/carousel.js"></script>
		</div>
	</body>
</html>