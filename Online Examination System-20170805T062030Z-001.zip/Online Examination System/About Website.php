<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

		<link rel='stylesheet' id='google_font_Open_Sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400%2C400italic%2C600%2C600italic%2C700%2C700italic%2C900%2C900italic&amp;subset=latin%2Cvietnamese%2Cgreek%2Ccyrillic-ext%2Clatin-ext%2Ccyrillic%2Cgreek-ext' type='text/css' media='all' />

		<link href="scripts/bxslider/jquery.bxslider.css" rel="stylesheet" />
		<link href="scripts/rs-plugin/css/settings.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="scripts/magnific-popup/magnific-popup.css" rel="stylesheet" />
		<link href="scripts/magnific-popup/magnific-popup-anim.css" rel="stylesheet" />

		<link rel="stylesheet" href="scripts/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="scripts/entypo/entypo.css">
		<link rel="stylesheet" href="scripts/zocial/zocial.css">

		<link rel="stylesheet" href="style.css" type="text/css"/>
		<link id="skin-style-css" rel="stylesheet" href="skins/blue/blue.css" type="text/css"/>

		<link href="scripts/colorpicker/css/colorpicker.css" rel="stylesheet" />

					<link rel="stylesheet" href="switcher/switcher.css" type="text/css"/>
		
				<style type='text/css'>
			body.boxed{ 
				background-color: #F5D29D; 
				background-image: url("images/boxed_wood.jpg");background-repeat: repeat;			}
		</style>
		
				
		<title>Abouy us</title>
	</head>
	<body class="">
		<div id="layout_width">
			<div class="content_container">
				<div class="header-2_container cwidth_container">
	<div class="header-2_wrapper cwidth_wrapper">
		<div class="header-2 clearfix cwidth">
			<div class="col-1-1">
				<div class="col">
					<div class="header-2_content clearfix">
						<div class="contact_info">
							<font size="4">Call Us: (0253) 2303357 / 2303358 - Mail : <a href="mailto: service@gmail.com">service@gmail.com</a></font>
						</div>
						<div class="header_right has_flags">
							<!--
								IMPORTANT, has_flags CLASS IS NEEDED TO BE PRINTED IF THERE ARE FLAGS PRESENT
							-->
							<div class="social_links">
								<a href="#" class="social_link icon-twitter"></a>
								<a href="#" class="social_link icon-dribbble"></a>
								<a href="#" class="social_link icon-facebook"></a>
								<a href="#" class="social_link icon-google-plus"></a>
								<a href="#" class="social_link icon-rss"></a>
								<a href="#" class="social_link icon-linkedin"></a>
							</div>
							<div class="flags_wrapper">
								<div class="flag_active clearfix">
									<!--
										IMPORTANT, has_flags CLASS IS NEEDED TO BE PRINTED IF THERE ARE FLAGS PRESENT
									-->
									<img src="images/flags/us.png" data-at2x="images/flags/us@2x.png" alt="">
									<i class="icon-caret-down"></i>
									<div class="flag_list">
										<a href="#" class="flag">
											<img src="images/flags/us.png" data-at2x="images/flags/us@2x.png" alt="">
				
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>				<div class="header_main_wrapper" data-position="fixed">
					<!--
					data-position="fixed";
					data-position="static";
					1 of these 2 params needs to be set
					-->
					<div class="header-1_container cwidth_container">
	<div class="header-1_wrapper cwidth_wrapper">
		<div class="header-1 cwidth">
			<div class="col-1-5">
				<div class="col">
					<a href="HomePage.php" class="logo">
						<img src="">
					</a>
				</div>
			</div>
			<div class="col-4-5">
				<div class="col">
					<div class="navigation-1_container">
	<div class="navigation-1_wrapper">
		<div class="navigation-1 fallback clearfix">


			<div class="navigation-desktop">
				<div class="menu-navigation-container">
					<ul class="menu" id="menu-navigation-desktop">
						<li class="menu-item menu-item-type-post_type menu-item-object-page top-menu-item top-menu-item-has-sub-menu"><a class="top-menu-item-a top-menu-item-has-sub-menu-a" href="HomePage.php"><span>Home</span></a>
							<ul class="sub-menu">
							</ul>
						</li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page top-menu-item top-menu-item-has-sub-menu"><a class="top-menu-item-a top-menu-item-has-sub-menu-a" href="Login.php"><span>Exam</span></a>
							<ul class="sub-menu">
								<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="Login.php">Start Exam</a></li>
								<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="Rules.php">Exam Rules</a></li>
			
							</ul>
						</li>
                        <li class="menu-item menu-item-type-post_type menu-item-object-page top-menu-item top-menu-item-has-sub-menu"><a class="top-menu-item-a top-menu-item-has-sub-menu-a" href="Help.php"><span>Help</span></a>
						
						</li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page top-menu-item top-menu-item-has-sub-menu"><a class="top-menu-item-a top-menu-item-has-sub-menu-a" href="About Website.php"><span>About us</span></a>
							<ul class="sub-menu">		
                            <li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="About Website.php">About Website</a></li>					
								<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="Contact.php">Contact</a></li>	
	
                            </ul>
			
					</ul>
				</div>
				<div class="clear"></div>
			</div>


		</div>
	</div>
</div>							</div>
			</div>
		</div>
	</div>
</div>

































	<!-- REVOLUTION SLIDER -->

	<script src="scripts/jquery/1.9.0/jquery.min.js"></script>
	<script src="scripts/imagesloaded/imagesloaded.min.js"></script>
	<script src="scripts/bxslider/jquery.bxslider.min.js"></script>
	<script src="scripts/caroufredsel/jquery.caroufredsel.min.js"></script>

	<script src="scripts/magnific-popup/magnific-popup.js"></script>
	<script src="scripts/isotope/jquery.isotope.min.js"></script>
	<script src="scripts/gmaps/jquery.gmaps.js"></script>
	<script src="scripts/countdown/jquery.countdown.js"></script>
	<script src="scripts/countdown/jquery.countdown_init.js"></script>
	<script src="scripts/retinajs/retinajs.min.js"></script>
	<script src="scripts/colorpicker/js/colorpicker.js"></script>
	<script type="text/javascript" src="scripts/rs-plugin/pluginsources/jquery.themepunch.plugins.min.js"></script>
	<script type="text/javascript" src="scripts/rs-plugin/pluginsources/jquery.themepunch.revolution.js"></script>

	<script type="text/javascript">

		var tpj=jQuery;
		//tpj.noConflict();

		tpj(document).ready(function() {

		if (tpj.fn.cssOriginal!=undefined)
			tpj.fn.css = tpj.fn.cssOriginal;

			tpj('.slider-1').revolution(
				{
					delay:9000,

					startwidth:1100, 						// 1100 = default content width
					startheight:451, 						

					onHoverStop:"on",						// Stop Banner Timet at Hover on Slide on/off

					hideThumbs:0,

					navigationType:"none",

				    soloArrowLeftHalign:"left",
					soloArrowLeftValign:"center",
					soloArrowLeftHOffset:25,
					soloArrowLeftVOffset:0,

					soloArrowRightHalign:"right",
					soloArrowRightValign:"center",
					soloArrowRightHOffset:25,
					soloArrowRightVOffset:0,

					touchenabled:"on",						// Enable Swipe Function : on/off



					stopAtSlide:-1,							// Stop Timer if Slide "x" has been Reached. If stopAfterLoops set to 0, then it stops already in the first Loop at slide X which defined. -1 means do not stop at any slide. stopAfterLoops has no sinn in this case.
					stopAfterLoops:-1,						// Stop Timer if All slides has been played "x" times. IT will stop at THe slide which is defined via stopAtSlide:x, if set to -1 slide never stop automatic

					hideCaptionAtLimit:0,					// It Defines if a caption should be shown under a Screen Resolution ( Basod on The Width of Browser)
					hideAllCaptionAtLilmit:0,				// Hide all The Captions if Width of Browser is less then this value
					hideSliderAtLimit:0,					// Hide the whole slider, and stop also functions if Width of Browser is less than this value


					fullWidth:"on",

					shadow:0								//0 = no Shadow, 1,2,3 = 3 Different Art of Shadows -  (No Shadow in Fullwidth Version !)

				});




	});
	</script>
	</div><!-- END BOXED -->
	<!-- Style switcher
================================================== -->

<div class="styleSwitcherWrapper">
  <div class="styleSwitcherPanel">

    <h4>BASIC OPTIONS</h4>

	
	<p class="skin_color_section">Skin Color <span style="background-color: #0093cf;"></span></p>
	<ul class="switcherSkin clearfix">
					<li>
				<a class="skin-burgundy" 
					data-value="burgundy" 
					href="skins/burgundy/burgundy.css" 
					style="background-color: #e52b50;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-magenta" 
					data-value="magenta" 
					href="skins/magenta/magenta.css" 
					style="background-color: #f20707;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-red" 
					data-value="red" 
					href="skins/red/red.css" 
					style="background-color: #ff3500;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-orange" 
					data-value="orange" 
					href="skins/orange/orange.css" 
					style="background-color: #ff760d;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-pink" 
					data-value="pink" 
					href="skins/pink/pink.css" 
					style="background-color: #de66c2;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-cobalt" 
					data-value="cobalt" 
					href="skins/cobalt/cobalt.css" 
					style="background-color: #277edc;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-blue selected" 
					data-value="blue" 
					href="skins/blue/blue.css" 
					style="background-color: #0093cf;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-cyan" 
					data-value="cyan" 
					href="skins/cyan/cyan.css" 
					style="background-color: #27ccc0;" 
				>
				</a>
			</li>
					<li>
				<a class="skin-green" 
					data-value="green" 
					href="skins/green/green.css" 
					style="background-color: #71be3c;" 
				>
				</a>
			</li>
			</ul>

	<p class="header_position">Header position<span>Fixed</span></p>
	<ul class="switcherHeaderLayout clearfix">
		<li><a class="header-fixed sw_button selected" data-value="fixed" href="#">Fixed</a></li>
		<li><a class="header-static sw_button" data-value="static" href="#">Static</a></li>
	</ul>

	<p class="page_layout_section">Page Layout<span>Fullwidth</span></p>

	<ul class="skin-use-boxed-layout clearfix">
		<li><a class="skin-use-boxed-layout-off sw_button selected" data-value="off" href="#">Fullwidth</a></li>
		<li><a class="skin-use-boxed-layout-on sw_button" data-value="on" href="#">Boxed</a></li>
	</ul>

		
		<div class="background_image_section_wrapper">
			<p class="background_image_section">Background <span style="background-image: url('images/boxed_wood.jpg');"></span></p>

			<ul class="skin-use-custom-background-image clearfix">
				<li><a class="skin-use-custom-background-image-on sw_button selected" data-value="on" href="#">Image</a></li>
				<li><a class="skin-use-custom-background-image-off sw_button" data-value="off" href="#">Color</a></li>
			</ul>

			<ul class="skin-boxed-background-image clearfix">
				<li><a class="predefined-background selected" href="#" style="background-image: url('images/boxed_wood.jpg');" title="./images/boxed_wood.jpg" data-value="images/boxed_wood.jpg"></a></li><li><a class="predefined-background" href="#" style="background-image: url('images/boxed_fabric.jpg');" title="./images/boxed_fabric.jpg" data-value="images/boxed_fabric.jpg"></a></li><li><a class="predefined-background" href="#" style="background-image: url('images/boxed_2.jpg');" title="./images/boxed_2.jpg" data-value="images/boxed_2.jpg"></a></li><li><a class="predefined-background" href="#" style="background-image: url('images/boxed_3.jpg');" title="./images/boxed_3.jpg" data-value="images/boxed_3.jpg"></a></li><li><a class="predefined-background" href="#" style="background-image: url('images/boxed_5.jpg');" title="./images/boxed_5.jpg" data-value="images/boxed_5.jpg"></a></li><li><a class="predefined-background" href="#" style="background-image: url('images/boxed_8.jpg');" title="./images/boxed_8.jpg" data-value="images/boxed_8.jpg"></a></li>			</ul>

			<div class="skin-boxed-background-color-wrapper custom_color_wrapper clearfix" style="display: none">
				<input value="F5D29D" class="skin-boxed-background-color" style="background-color:#F5D29D;color:_transparent; border-color: #F5D29D" type="text" />
				<div class="color_dot" style="background-color:#F5D29D;"></div>
			</div>
			<script>
			jQuery(document).ready(function($){
				$(".skin-boxed-background-color").ColorPicker({
					onSubmit: function(hsb, hex, rgb, el) {
						$(el).css("border-color", '#' + hex);
						$(el).siblings('.color_dot').css("background-color", '#' + hex);
						$(el).val(hex);
						$(el).ColorPickerHide();
					}, // onSubmit
					onChange: function (hsb, hex, rgb) {
						jQuery(".skin-boxed-background-color").css("border-color", "#" + hex);
						jQuery(".skin-boxed-background-color").siblings('.color_dot').css("background-color", "#" + hex);
						$(".skin-boxed-background-color").val(hex);
						$(".skin-boxed-background-color").change();

					} // onChange
				}); // .ColorPicker({
			}); // jQuery(document).ready(function($){
			</script>
		</div>


    <p>RESET SETTINGS</p>
    <a class="resetCookies sw_button" href="#"

data-header-position                  ="fixed"
data-skin-accent                      ="blue"
data-skin-boxed-background-color      ="F5D29D"
data-skin-boxed-background-image      ="./images/boxed_wood.jpg"
data-skin-use-boxed-layout            ="off"
data-skin-use-custom-background-image ="on"

    >Reset All</a>

    <div class="clear"></div>
  </div>
  <a href="#" class="styleSwitcherToggle">
    <span class="styleSwitcherToggleImage"></span>
  </a>
</div>

<script src="switcher/cookie.js" type="text/javascript"></script>
<script src="switcher/switcher.js" type="text/javascript"></script>


<!-- Style switcher END
================================================== -->

	<script type="text/javascript" src="js/global.js"></script>
</body>
</script>