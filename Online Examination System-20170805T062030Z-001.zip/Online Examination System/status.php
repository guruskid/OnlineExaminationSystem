<html>
<head>
<title></title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/respond.js"></script>  
</head>
<br><div class="alert alert-danger" role="alert"><center>This user is already logged in.</center></div>

<?php 
	exit;
?>

<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</html>